package mla.mar_22_relationships.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class College {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long id;
	private String name;
	//One College belong to One university
	@ManyToOne(targetEntity = University.class)
	private University university;
	
	public College() {}

	public College(Long id, String name, University university) {
		this.id = id;
		this.name = name;
		this.university = university;
	}
	public College(String name, University university) {

		this.name = name;
		this.university = university;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public University getUniversity() {
		return university;
	}

	public void setUniversity(University university) {
		this.university = university;
	}

	@Override
	public String toString() {
		return "College [id=" + id + ", name=" + name + ", university=" + university.getName() + "]";
	}

}
