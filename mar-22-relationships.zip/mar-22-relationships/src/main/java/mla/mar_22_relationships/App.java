package mla.mar_22_relationships;

import java.io.Serializable;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.BasicConfigurator;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import mla.mar_22_relationships.model.College;
import mla.mar_22_relationships.model.University;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	BasicConfigurator.configure();
    	Scanner sc=new Scanner(System.in);
    	
    	Configuration config=new Configuration();
    	config.configure("hibernate.cfg.xml");
    	Session session = config.buildSessionFactory().openSession();
    	
		/*
		 * University university=new University("Annamalai University", "Karaikudi");
		 * Transaction tran = session.beginTransaction(); Serializable id =
		 * session.save(university); tran.commit();
		 */
    	
    	//to add a college 
    	University university=(University) session.get(University.class, 4220L);
    	System.out.println(university);
    	sc.nextLine();
    	System.out.println("hello 1");
    	University university1=(University) session.get(University.class, 4220L);
    	System.out.println(university1);
    	System.out.println("hellop 2");
//    	College college=new College("XYZ college", university);
//    	Transaction tran = session.beginTransaction();
//    	session.save(college);
//    	tran.commit();
//    	session.close();
//    	System.out.println(university);
//    	List<College> colleges = university.getCollegeList();
////    	System.out.println(colleges.size());
//    	for(College c: colleges)
//    		System.out.println(c);
        System.out.println( "Hello World!" );
    }
}
