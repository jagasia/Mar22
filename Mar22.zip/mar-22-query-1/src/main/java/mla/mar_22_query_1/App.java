package mla.mar_22_query_1;

import java.text.ParseException;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import mla.mar_22_query_1.model.Customer;
import mla.mar_22_query_1.model.CustomerDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws ParseException
    {
    	Configuration config=new Configuration();
    	config.configure("hibernate.cfg.xml");
    	config.addAnnotatedClass(Customer.class);
    	SessionFactory sf = config.buildSessionFactory();
    	Session session = sf.openSession();
    	Query query = session.getNamedQuery("findByCity");
    	query.setString("city", "Delhi");
    	List<Customer> result = query.list();
    	for(Customer c : result)
    		System.out.println(c);
    }
}
