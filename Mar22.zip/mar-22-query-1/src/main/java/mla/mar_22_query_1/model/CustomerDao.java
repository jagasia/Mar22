package mla.mar_22_query_1.model;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CustomerDao {
	private Session getConnection()
	{
		Configuration config=new Configuration();
    	config.addAnnotatedClass(Customer.class);
    	config.configure("hibernate.cfg.xml");
    	Session session = config.buildSessionFactory()
    	.openSession();
    	return session;
	}
	public String create(Customer customer)
	{
		Session session = getConnection();
//		Query query = session.createQuery("INSERT INTO Customer c VALUES (customerId, firstName, middleName, lastName, city, mobileNo, occupation, dateOfBirth) (?,?,?,?,?,?,?)");
//		query.setString(1, customer.getCustomerId());
//		query.setString(2, customer.getFirstName());
//		query.setString(3, customer.getMiddleName());
//		query.setString(4, customer.getLastName());
//		query.setString(5, customer.getCity());
//		query.setString(6, customer.getMobileNo());
//		query.setString(7, customer.getOccupation());
//		query.setString(8, customer.getDateOfBirth1());
//		
//		int no=query.executeUpdate();
		Transaction tran = session.beginTransaction();
		String id=(String) session.save(customer);
		tran.commit();
		session.close();
		return id;
	}
	public List<Customer> read()
	{
		Session session = getConnection();
		Query query = session.createQuery("FROM Customer c");
		List<Customer> result = query.list();
		return result;
	}
	public List<Customer> read(String customerId)
	{
		Session session = getConnection();
		Query query = session.createQuery("FROM Customer c WHERE c.customerId=:cid");
		query.setString("cid", customerId);
		List<Customer> result = query.list();
		return result;
	}
	public int update(Customer c)
	{
		Session session = getConnection();
		Transaction tran = session.beginTransaction();
		Query query = session.createQuery("UPDATE Customer SET firstName=?, middleName=?, lastName=?, city=?, mobileNo=?, occupation=?, dateOfBirth=? WHERE customerId=:cid");
		query.setString(0, c.getFirstName());
		query.setString(1, c.getMiddleName());
		query.setString(2, c.getLastName());
		query.setString(3, c.getCity());
		query.setString(4, c.getMobileNo());
		query.setString(5, c.getOccupation());
		query.setString(6, c.getDateOfBirth1());
		query.setString("cid", c.getCustomerId());
		int no=query.executeUpdate();
		tran.commit();
		session.close();
		return no;
	}
	public int delete(String customerId)
	{
		Session session = getConnection();
		Transaction tran = session.beginTransaction();
		Query query = session.createQuery("DELETE FROM Customer c WHERE c.customerId=?");
		query.setString(0, customerId);
		int no=query.executeUpdate();
		tran.commit();
		session.close();
		return no;
	}
	
}
