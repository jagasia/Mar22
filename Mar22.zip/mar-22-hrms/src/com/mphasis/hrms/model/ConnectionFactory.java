package com.mphasis.hrms.model;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

public class ConnectionFactory {
	public static Session getConnection()
	{
		Configuration config=new Configuration();
		config.configure("hibernate.cfg.xml");
		return config.buildSessionFactory().openSession();
	}
}
