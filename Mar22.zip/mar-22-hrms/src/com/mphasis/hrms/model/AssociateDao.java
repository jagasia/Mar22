package com.mphasis.hrms.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class AssociateDao {
	public Serializable create(Associate associate)
	{
		Session session = ConnectionFactory.getConnection();
		Transaction tran = session.beginTransaction();
		Serializable id = session.save(associate);
		tran.commit();
		session.close();
		return id;
	}
	public List<Associate> read()
	{
		Session session = ConnectionFactory.getConnection();
		return session.createCriteria(Associate.class).list();
	}
	public Associate read(Long associateId)
	{
		Session session = ConnectionFactory.getConnection();
		return (Associate) session.get(Associate.class, associateId);
	}
	public void update(Associate associate)
	{
		Session session = ConnectionFactory.getConnection();
		Associate old=(Associate) session.get(Associate.class, associate.getAssociateId());
		Transaction tran = session.beginTransaction();
		old.setFirstName(associate.getFirstName());
		old.setLastName(associate.getLastName());
		old.setGender(associate.getGender());
		old.setDateOfJoining(associate.getDateOfJoining());
		old.setPicture(associate.getPicture());
		session.persist(old);
		tran.commit();
		session.close();
	}
	public void delete(Long associateId)
	{
		Session session = ConnectionFactory.getConnection();
		Associate old=(Associate) session.get(Associate.class, associateId);
		Transaction tran = session.beginTransaction();
		session.delete(old);
		tran.commit();
		session.close();
	}
	public static void main(String[] args) throws IOException {
		AssociateDao adao=new AssociateDao();
		File file=new File("C:\\Users\\rjaga\\Pictures\\we-zoom-5.jpg");
		FileInputStream fis=new FileInputStream(file);
		int len=(int) file.length();
		byte []data=new byte[len];
		fis.read(data);
		fis.close();
		//Associate a=new Associate(381L,"Dinesh", "Srinivasan", new Date(), "Male", data);
//		Serializable id = adao.create(a);
//		System.out.println("Note down the id: "+id);
//		adao.update(a);
		adao.delete(381L);
	}
}
