package com.mphasis.hrms.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.mphasis.hrms.model.Associate;
import com.mphasis.hrms.model.AssociateDao;

/**
 * Servlet implementation class AssociateServlet
 */
@MultipartConfig
@WebServlet({ "/AssociateServlet", "/associate" })
public class AssociateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssociateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String btn=request.getParameter("btn");
		Long associateId=null;
		if(request.getParameter("associateId")!=null)
		{
			if(!request.getParameter("associateId").equals("Choose..."))
				associateId=Long.valueOf(request.getParameter("associateId"));
		}
			
		String firstName="";
		String lastName="";
		String sdate="";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date dateOfJoining=null;
		String gender="";
		Associate associate=null;
//		AssociateDaoImpl adao=new AssociateDaoImpl();
		AssociateDao adao = new AssociateDao();
		Serializable no=0;
		if(btn.equals("Add") || btn.equals("Modify"))
		{
			firstName=request.getParameter("firstName");
			lastName=request.getParameter("lastName");
			sdate=request.getParameter("dateOfJoining");
			
			try {
				dateOfJoining=sdf.parse(sdate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(dateOfJoining==null)
				return;
			
			gender=request.getParameter("gender");
			//code for accessing file contents as byte array
			Part part = request.getPart("picture");
			InputStream is = part.getInputStream();
			int len = is.available();
			byte []picture=new byte[len];
			is.read(picture);
			if(btn.equals("Add"))
				associate=new Associate(firstName, lastName, dateOfJoining, gender, picture);
			else
				associate=new Associate(associateId, firstName, lastName, dateOfJoining, gender, picture);
		}
		switch(btn)
		{
		case "Add":
			if(associateId==null)
			{
					no=adao.create(associate);
				System.out.println("Note down the id: "+no);
			}
			break;
		case "Modify":
			if(associate!=null)
			{
					adao.update(associate);

			}
			break;
		case "Delete":
				adao.delete(associateId);
			break;
		}
		//redirect back to jsp again
		response.sendRedirect("associate3.jsp");

	}

}
